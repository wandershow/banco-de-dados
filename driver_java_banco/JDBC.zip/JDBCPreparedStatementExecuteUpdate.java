import java.sql.*;

//INSERT, UPDATE e DELETE
public class JDBCPreparedStatementExecuteUpdate
{	public static void main(String args[])
	{	Connection connection = null;
		PreparedStatement preparedstatement = null;

		try
		{	Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost/dbname", "username", "password");
			if (connection != null)
			{	preparedstatement = connection.prepareStatement("INSERT INTO employee (name, profit) VALUES (?, ?)");
				preparedstatement.setString(1, "John");
				preparedstatement.setFloat(2, 1000);
				preparedstatement.executeUpdate();
				System.out.println(preparedstatement.getUpdateCount() + " rows were affected by this statement.");
				preparedstatement.close();
				connection.close();
			}
		}
		catch (Exception e)
		{	e.printStackTrace();
		}
	}
}

