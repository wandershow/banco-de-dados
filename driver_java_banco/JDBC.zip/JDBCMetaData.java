import java.sql.*;
import java.util.Scanner;

//javac JDBCMetaData.java && java -cp .:./jdbc???.jar JDBCMetaData

public class JDBCMetaData
{	public static void main(String args[])
	{	Connection connection = null;
		Statement statement = null;
		ResultSet resultset = null;
		DatabaseMetaData databasemetadata = null;
		ResultSetMetaData resultsetmetadata = null;
		Scanner scanner = new Scanner(System.in);
		int row = 0;
		int column = 0;

		try
		{	Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost/dbname", "username", "password");
			if (connection != null)
			{	databasemetadata = connection.getMetaData();
				System.out.println("Connection to " + databasemetadata.getDatabaseProductName() + " " + databasemetadata.getDatabaseProductVersion() + " successful.");
				statement = connection.createStatement();
				System.out.print("SQL? ");
				resultset = statement.executeQuery(scanner.nextLine());
				resultsetmetadata = resultset.getMetaData();
				for (column = 1; column <= resultsetmetadata.getColumnCount(); column++)
				{	System.out.println("Column " + column + ": " + resultsetmetadata.getTableName(column) + ", " + resultsetmetadata.getColumnName(column) + ", " + resultsetmetadata.getColumnTypeName(column) + ", " + resultsetmetadata.getPrecision(column));
				}
				while (resultset.next())
				{	System.out.print("Row " + (++row) + ": " + resultset.getString(1));
					for (column = 2; column <= resultsetmetadata.getColumnCount(); column++)
					{	System.out.print(", " + resultset.getString(column));
					}
					System.out.println();
				}
				resultset.close();
				statement.close();
				connection.close();
			}
		}
		catch (Exception e)
		{	e.printStackTrace();
		}
	}
}

