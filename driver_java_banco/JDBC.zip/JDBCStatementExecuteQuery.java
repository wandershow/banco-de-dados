import java.sql.*;

//SELECT
public class JDBCStatementExecuteQuery
{	public static void main(String args[])
	{	Connection connection = null;
		Statement statement = null;
		ResultSet resultset = null;
		int row = 0;

		try
		{	Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost/dbname", "username", "password");
			if (connection != null)
			{	statement = connection.createStatement();
				resultset = statement.executeQuery("SELECT * FROM employee WHERE profit > 1000");
				while (resultset.next())
				{	System.out.println("Row " + (++row) + ": " + resultset.getString("name") + ", " + resultset.getFloat(2));
				}
				resultset.close();
				statement.close();
				connection.close();
			}
		}
		catch (Exception e)
		{	e.printStackTrace();
		}
	}
}

