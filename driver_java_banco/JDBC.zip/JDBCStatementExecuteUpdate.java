import java.sql.*;

//INSERT, UPDATE e DELETE
public class JDBCStatementExecuteUpdate
{	public static void main(String args[])
	{	Connection connection = null;
		Statement statement = null;

		try
		{	Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost/dbname", "username", "password");
			if (connection != null)
			{	statement = connection.createStatement();
				statement.executeUpdate("INSERT INTO table (name, profit) VALUES ('John', 1000)");
				System.out.println(statement.getUpdateCount() + " rows were affected by this statement.");
				statement.close();
				connection.close();
			}
		}
		catch (Exception e)
		{	e.printStackTrace();
		}
	}
}

