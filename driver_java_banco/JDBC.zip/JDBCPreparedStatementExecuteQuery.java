import java.sql.*;

//SELECT
public class JDBCPreparedStatementExecuteQuery
{	public static void main(String args[])
	{	Connection connection = null;
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		int row = 0;

		try
		{	Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection("jdbc:postgresql://localhost/dbname", "username", "password");
			if (connection != null)
			{	preparedstatement = connection.prepareStatement("SELECT * FROM employee WHERE profit > ?");
				preparedstatement.setFloat(1, 1000);
				resultset = preparedstatement.executeQuery();
				while (resultset.next())
				{	System.out.println("Row " + (++row) + ": " + resultset.getString("name") + ", " + resultset.getFloat(2));
				}
				resultset.close();
				preparedstatement.close();
				connection.close();
			}
		}
		catch (Exception e)
		{	e.printStackTrace();
		}
	}
}

